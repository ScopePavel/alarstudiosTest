//
//  LoginAssembly.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 25/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "LoginAssembly.h"

@implementation LoginAssembly

+ (LoginViewController *) setupScene {
    UIStoryboard * storyBoard = [UIStoryboard storyboardWithName:@"Login" bundle:nil];
    LoginViewController * viewController = [storyBoard instantiateViewControllerWithIdentifier:@"LoginViewController"];
    viewController.modalPresentationStyle = UIModalPresentationFullScreen;
    return viewController;
}

@end
