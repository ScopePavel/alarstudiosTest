//
//  AirportsModel.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AirportsModel.h"

@implementation AirportsModel

@end
