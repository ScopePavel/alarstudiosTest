//
//  AppDelegate.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

