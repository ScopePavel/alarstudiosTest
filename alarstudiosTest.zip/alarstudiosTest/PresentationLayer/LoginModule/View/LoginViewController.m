//
//  LoginViewController.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 25/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "LoginViewController.h"
#import "NetworkManager.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *loginText;
@property (weak, nonatomic) IBOutlet UITextField *passwordText;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;
@property (strong, nonatomic) NetworkManager *networkManager;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.networkManager = NetworkManager.sharedManager;
}
- (IBAction)signInAction:(id)sender {
    
    if([self.loginText.text isEqualToString:@""] || [self.passwordText.text isEqualToString:@""]) {
        self.messageLabel.text = @"enter password and login";
        return;
    }
    __weak typeof (self) weakSelf = self;
    [self.networkManager signInLogin:self.loginText.text password:self.passwordText.text status:^(NSNumber * _Nonnull status) {
        
        if(status.boolValue == YES) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                weakSelf.messageLabel.text = @"Wrong password or login";
            });
        }
    }];
    
    
}

@end
