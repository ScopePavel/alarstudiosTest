//
//  AirportsModel.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AirportsModel : NSObject
@property (strong, nonatomic) NSString * name;
@property (strong, nonatomic) NSString * country;
@property (strong, nonatomic) NSString * idAirport;
@property (strong, nonatomic) NSNumber * lat;
@property (strong, nonatomic) NSNumber * lon;

@end

NS_ASSUME_NONNULL_END
