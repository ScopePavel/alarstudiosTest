//
//  AirportsViewController.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AirportsViewController.h"
#import "AiroportCell.h"
#import "NetworkManager.h"
#import "AirportsModel.h"
#import "AirportsDetailAssembly.h"
@interface AirportsViewController ()

@property (strong, nonatomic) NSMutableArray<AirportsModel *> *airoportsModel;
@property (strong, nonatomic) NSArray<NSDictionary *> *array;
@property (strong, nonatomic) NetworkManager *networkManager;
@property (strong, nonatomic) NSNumber *countOfLoadPages;

@end

@implementation AirportsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    __weak typeof (self) weakSelf = self;
    self.networkManager = NetworkManager.sharedManager;
    
    self.countOfLoadPages = @(1);
    NSString * code = [[NSUserDefaults standardUserDefaults] objectForKey:@"code"];
    [self.networkManager getAirportWithCode:code page:self.countOfLoadPages airoports:^(NSMutableArray<AirportsModel *> * _Nonnull airoports) {
        
        weakSelf.airoportsModel = airoports;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.tableView reloadData];
        });
    }];
    
}

// MARK: - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.airoportsModel.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

    
    
    AiroportCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AiroportCell" forIndexPath:indexPath];
    cell.airoportName.text = self.airoportsModel[indexPath.row].name;
    
    
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSURL *imageURL = [NSURL URLWithString:@"https://image.freepik.com/free-icon/_318-1385.jpg"];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
    
        dispatch_sync(dispatch_get_main_queue(), ^{
            cell.iconImage.image = [UIImage imageWithData: imageData];
        });
        
    });
    
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    __weak typeof (self) weakSelf = self;
    NSInteger lastRow = indexPath.row;
    if (lastRow == self.airoportsModel.count - 1) {
    
        int value = [self.countOfLoadPages intValue];
        self.countOfLoadPages = [NSNumber numberWithInt:value + 1];
        NSString * code = [[NSUserDefaults standardUserDefaults] objectForKey:@"code"];
        [weakSelf.networkManager getAirportWithCode:code page:self.countOfLoadPages airoports:^(NSMutableArray<AirportsModel *> * _Nonnull airoports) {
            
            [weakSelf.airoportsModel addObjectsFromArray:airoports];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tableView reloadData];
            });
            
        }];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.000001;
}

// MARK: - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    AirportsDetailViewController *airportsDetailViewController = [AirportsDetailAssembly setupSceneWithModel:self.airoportsModel[indexPath.row]];
    
    [self.navigationController pushViewController: airportsDetailViewController animated:YES];
}


@end
