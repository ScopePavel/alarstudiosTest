//
//  ViewController.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "ViewController.h"
#import "Assembly.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSUserDefaults standardUserDefaults] setObject:@"No" forKey:@"isSignIn"];
    [self presentViewController:[LoginAssembly setupScene] animated:NO completion:nil];
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if([[NSUserDefaults standardUserDefaults] objectForKey:@"isSignIn"]) {
        [self.navigationController pushViewController:[AirportsAssembly setupScene] animated:NO];
    }
    
    
}






@end
