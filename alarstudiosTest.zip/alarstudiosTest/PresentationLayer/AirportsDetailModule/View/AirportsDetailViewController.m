//
//  AirportsDetailViewController.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AirportsDetailViewController.h"
@import MapKit;
@interface AirportsDetailViewController ()

@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UILabel *countryLabel;
@property (weak, nonatomic) IBOutlet UILabel *idAirportLabel;

@end

@implementation AirportsDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [NSString stringWithFormat:@"country: %@",self.country];
    self.countryLabel.text = [NSString stringWithFormat:@"Country: %@",self.country];
    self.idAirportLabel.text = [NSString stringWithFormat:@"id: %@",self.idAirport];
    [self createPointOnMap];

}

- (void) createPointOnMap {
    MKPointAnnotation*    annotation = [[MKPointAnnotation alloc] init];
    CLLocationCoordinate2D myCoordinate;
    myCoordinate.latitude = self.latitude;
    myCoordinate.longitude = self.longitude;
    annotation.coordinate = myCoordinate;
    
    MKCoordinateSpan span;
    span.latitudeDelta = 0.05;
    span.longitudeDelta = 0.05;
    
    
    CLLocationCoordinate2D start;
    start.latitude = self.latitude;
    start.longitude = self.longitude;
    
    
    MKCoordinateRegion region;
    region.span = span;
    region.center = start;
    
    
    
    
    [self.mapView setRegion:region];
    [self.mapView addAnnotation:annotation];
}


@end
