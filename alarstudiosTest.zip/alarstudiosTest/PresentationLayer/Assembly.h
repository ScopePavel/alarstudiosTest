//
//  Assembly.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#ifndef Assembly_h
#define Assembly_h

#import "AirportsDetailAssembly.h"
#import "AirportsAssembly.h"
#import "LoginAssembly.h"
#endif /* Assembly_h */

