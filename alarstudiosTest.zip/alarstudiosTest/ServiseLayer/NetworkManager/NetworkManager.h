//
//  NetworkManager.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AirportsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface NetworkManager : NSObject
+ (id)sharedManager;

- (void)getAirportWithCode:(NSString *)code  page:(NSNumber *)page airoports:(void (^) (NSMutableArray<AirportsModel *> * airoports))airoports;
- (void)signInLogin:(NSString *)login password:(NSString *)password status:(void (^) (NSNumber* status))status;

@end

NS_ASSUME_NONNULL_END
