//
//  AiroportCell.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AiroportCell.h"

@implementation AiroportCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
