//
//  AirportsDetailAssembly.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AirportsDetailViewController.h"
#import "AirportsModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface AirportsDetailAssembly : NSObject

+ (AirportsDetailViewController *) setupSceneWithModel:(AirportsModel *)model;

@end

NS_ASSUME_NONNULL_END
