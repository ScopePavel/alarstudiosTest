//
//  AirportsDetailViewController.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AirportsDetailViewController : UIViewController
@property (assign, nonatomic) double latitude;
@property (assign, nonatomic) double longitude;
@property (strong, nonatomic)  NSString *country;
@property (weak, nonatomic)  NSString *idAirport;
@end

NS_ASSUME_NONNULL_END
