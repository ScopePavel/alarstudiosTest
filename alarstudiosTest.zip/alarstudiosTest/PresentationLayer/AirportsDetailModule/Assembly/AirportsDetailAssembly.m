//
//  AirportsDetailAssembly.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AirportsDetailAssembly.h"

@implementation AirportsDetailAssembly
+ (AirportsDetailViewController *) setupSceneWithModel:(AirportsModel *)model {
    UIStoryboard * storyBoard = [UIStoryboard storyboardWithName:@"AirportsDetail" bundle:nil];
    AirportsDetailViewController * viewController = [storyBoard instantiateViewControllerWithIdentifier:@"AirportsDetailViewController"];
    viewController.title = model.name;
    viewController.latitude = model.lat.doubleValue;
    viewController.longitude = model.lon.doubleValue;
    viewController.country = model.country;
    viewController.idAirport = model.idAirport;
    return viewController;
}
@end
