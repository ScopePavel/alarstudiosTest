//
//  NetworkManager.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 24/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "NetworkManager.h"

@interface NetworkManager()
@property (strong, nonatomic) NSArray<NSDictionary *> * array;
@end

@implementation NetworkManager

+ (id)sharedManager {
    static NetworkManager *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

- (void)getAirportWithCode:(NSString *)code  page:(NSNumber *)page airoports:(void (^) (NSMutableArray<AirportsModel *> * airoports))airoports {
    __weak typeof (self) weakSelf = self;
    
    
    NSMutableArray<AirportsModel *>* airportsModel = [NSMutableArray new];
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSString *urlString = [NSString stringWithFormat:@"https://www.alarstudios.com/test/data.cgi?code=%@&p=%@",code, page.stringValue];
    NSURL *url = [NSURL URLWithString: urlString];
    
    NSURLSessionDataTask *task = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if(data) {
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            weakSelf.array = [responseDic objectForKey:@"data"];
            
            for(NSDictionary *dict in weakSelf.array) {
                
                AirportsModel * model = [AirportsModel new];
                model.lat = [dict objectForKey:@"lat"];
                model.lon = [dict objectForKey:@"lon"];
                model.name = [dict objectForKey:@"name"];
                model.country = [dict objectForKey:@"country"];
                model.idAirport = [dict objectForKey:@"id"];
                
                [airportsModel addObject:model];
            }
            
            airoports(airportsModel);
        }
    }];
    
    [task resume];

}

- (void)signInLogin:(NSString *)login password:(NSString *)password status:(void (^) (NSNumber* status))status {
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSString *urlString = [NSString stringWithFormat:@"https://www.alarstudios.com/test/auth.cgi?username=%@&password=%@",login, password];
    NSURL *url = [NSURL URLWithString: urlString];
    
    NSURLSessionDataTask *task = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if(data) {
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            if([[responseDic objectForKey:@"status"] isEqualToString:@"ok"]) {
                NSNumber *statusOk = @(YES);
                [[NSUserDefaults standardUserDefaults] setObject:[responseDic objectForKey:@"code"] forKey:@"code"];
                [[NSUserDefaults standardUserDefaults] setObject:[responseDic objectForKey:@"yes"] forKey:@"isSignIn"];
                status(statusOk);
            } else {
                NSNumber *statusNo = @(NO);
                status(statusNo);
            }
        }
        
    }];
    
    [task resume];

}


@end
