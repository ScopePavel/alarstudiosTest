//
//  AirportsAssembly.h
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AirportsViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface AirportsAssembly : NSObject

+ (AirportsViewController *) setupScene;

@end

NS_ASSUME_NONNULL_END


