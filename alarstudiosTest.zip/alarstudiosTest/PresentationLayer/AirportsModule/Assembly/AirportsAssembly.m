//
//  AirportsAssembly.m
//  alarstudiosTest
//
//  Created by Паронькин Павел on 23/10/2019.
//  Copyright © 2019 pavelPavel. All rights reserved.
//

#import "AirportsAssembly.h"

@implementation AirportsAssembly

+ (AirportsViewController *) setupScene {
    UIStoryboard * storyBoard = [UIStoryboard storyboardWithName:@"Airports" bundle:nil];
    AirportsViewController * viewController = [storyBoard instantiateViewControllerWithIdentifier:@"AirportsViewController"];
    return viewController;
}

@end
